import typer
import sys
import re
import logging
import os



logging.basicConfig(filename='test1.log', level=logging.DEBUG,
                    format='%(asctime)s: %(levelname)s:%(message)s ',datefmt='%b %d %H:%M:%S')

app = typer.Typer()


#To Create data for log files

def add(x, y):
    """Add Function"""
    return x + y


def subtract(x, y):
    """Subtract Function"""
    return x - y


def multiply(x, y):
    """Multiply Function"""
    return x * y


def divide(x, y):
    """Divide Function"""
    return x / y


num_1 = 20
num_2 = 10

add_result = add(num_1, num_2)
logging.debug('Add: {} + {} = {}'.format(num_1, num_2, add_result))

sub_result = subtract(num_1, num_2)
logging.debug('Sub: {} - {} = {}'.format(num_1, num_2, sub_result))

mul_result = multiply(num_1, num_2)
logging.debug('Mul: {} * {} = {}'.format(num_1, num_2, mul_result))

div_result = divide(num_1, num_2)
logging.debug('Div: {} / {} = {}'.format(num_1, num_2, div_result))


#To create supported options

#Print first NUM lines
@app.command()
def f(num: int, file:str):
    from itertools import islice
    n = num
    with open(file, "r") as myfile:
        flines = list(islice(myfile, n))
        print(flines)

#Print Last NUM lines
@app.command()
def l(num: int, file:str):
    n = num
    with open(file, "r") as myfile:
        
        for line in(myfile.readlines() [-n:]):
            print(line, end ='')
        
#Print lines that contain a timestamp in HH:MM:SS format
@app.command()
def t(file:str):
    regexTimeStamp = re.compile(r'(\d{2}:\d{2}:\d{2})')
    
    with open(file, "r") as myfile:
        data = myfile.readlines()
        
        for line in data:
            if regexTimeStamp.search(line):
                print(line)  
                
                
# Print lines that contain an IPv4 address, matching are highlighted              
@app.command()
def ipv4(file:str): 
    regexIPv4 = re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')
    with open(file, "r") as myfile:
        
        data = myfile.readlines()
        
        for line in data:
            if regexIPv4.search(line):
                print(line)  

#Print lines that contain an IPv6 address (standard notation), matching IPs are highlighted
@app.command()
def ipv6(file:str): 
    regexIPv6 = re.compile('((([0-9a-fA-F]){1,4})\\:){7}([0-9a-fA-F]){1,4}')
    with open(file, "r") as myfile:
        
        data = myfile.readlines()
        
        for line in data:
            if regexIPv6.search(line):
                print(line)  

#prints any of the last 50 lines from test_5.log that contain an IPv4address>                
@app.command()
def lastipv4(num:int, file:str):
    regexIPv4 = re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')
    with open(file, "r") as myfile:
        
        data = myfile.readlines()
        length = len(data)
        x = length
        n = 0
        for line in (data[-x:]):
            if regexIPv4.search(line) and n < num:
                n += 1 
                print(line)  

        
    
if __name__ == "__main__":
    app()