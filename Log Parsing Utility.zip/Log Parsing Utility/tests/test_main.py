from typer.testing import CliRunner

from main import app

runner = CliRunner()


def test_f():
    result = runner.invoke(app, ["f", "1", "test.log"])
    assert result.exit_code == 0
    print(result.stdout)
    assert "2022-03-17 17:31:11,089:DEBUG:Add: 20 + 10 = 30" in result.stdout
 
def test_l():
    result = runner.invoke(app, ["l", "1", "test.log"])
    assert result.exit_code == 0
    print(result.stdout)
    assert "Mar 18 14:57:24 999.10.20.30:DEBUG:Div: 20 / 10 = 7.0" in result.stdout

def test_t():
    result = runner.invoke(app, ["t","test.log"])
    assert result.exit_code == 0
    print(result.stdout)
    assert "2022-03-17 17:31:11,089:DEBUG:Add: 20 + 10 = 30" in result.stdout
    
def test_ipv4():
    result = runner.invoke(app, ["ipv4","test.log"])
    assert result.exit_code == 0
    print(result.stdout)
    assert "Mar 18 14:57:24 999.10.20.30:DEBUG:Div: 20 / 10 = 7.0" in result.stdout   
    
def test_ipv6():
    result = runner.invoke(app, ["ipv6","test.log"])
    assert result.exit_code == 0
    print(result.stdout)
    assert "2001:db8:3333:4444:5555:6666:7777:8888" in result.stdout

def test_lastipv4():
    result = runner.invoke(app, ["lastipv4", "50", "test.log"])
    assert result.exit_code == 0
    print(result.stdout)
    assert "Mar 18 14:57:24 10.0.0.2 :DEBUG:Div: 20 / 10 = 2.0" in result.stdout